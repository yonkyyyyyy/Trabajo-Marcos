package com.example.RDMProject.controller;

import com.example.RDMProject.dto.AuthRequest;
import com.example.RDMProject.model.Usuario;
import com.example.RDMProject.repository.UsuarioRepository;
import com.example.RDMProject.service.JwtService;
import com.example.RDMProject.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final UsuarioRepository repo;
    private final BCryptPasswordEncoder encoder;
    private final JwtService jwtService;

    @Autowired
    private UsuarioService usuarioService;

    public AuthController(UsuarioRepository repo, BCryptPasswordEncoder encoder, JwtService jwtService) {
        this.repo = repo;
        this.encoder = encoder;
        this.jwtService = jwtService;
    }

    /**
     * Muestra el formulario de login
     * IMPORTANTE: Verifica que exista templates/login.html en tu proyecto
     */
    @GetMapping("/login")
    public String loginPage(
            @RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout,
            @RequestParam(value = "registro", required = false) String registro,
            Model model) {

        if (error != null) {
            model.addAttribute("error", "Usuario o contraseña incorrectos");
        }

        if (logout != null) {
            model.addAttribute("mensaje", "Has cerrado sesión exitosamente");
        }

        if (registro != null) {
            model.addAttribute("mensaje", "Registro exitoso. Ahora puedes iniciar sesión.");
        }

        // Retorna "login" - Spring busca templates/login.html
        return "login";
    }

    /**
     * Muestra el formulario de registro
     * IMPORTANTE: Verifica que exista templates/register.html en tu proyecto
     */
    @GetMapping("/register")
    public String showRegister(Model model) {
        model.addAttribute("usuario", new Usuario());
        // Retorna "register" - Spring busca templates/register.html
        return "register";
    }

    /**
     * Procesa el registro de nuevo usuario
     */
    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("usuario") Usuario usuario,
                           BindingResult result,
                           Model model,
                           RedirectAttributes redirectAttributes) {

        System.out.println("=== INICIO REGISTRO ===");
        System.out.println("Username: " + usuario.getUsername());
        System.out.println("Email: " + usuario.getEmail());
        System.out.println("Nombre completo: " + usuario.getNombreCompleto());

        // Validar errores de validación
        if (result.hasErrors()) {
            System.out.println("ERRORES DE VALIDACIÓN:");
            result.getAllErrors().forEach(error -> {
                System.out.println("  - " + error.getDefaultMessage());
            });
            return "register";
        }

        // Validar que el username no exista
        if (usuarioService.existsByUsername(usuario.getUsername())) {
            System.out.println("ERROR: Username ya existe");
            model.addAttribute("error", "El nombre de usuario ya existe");
            return "register";
        }

        // Validar que el email no exista
        if (usuarioService.existsByEmail(usuario.getEmail())) {
            System.out.println("ERROR: Email ya existe");
            model.addAttribute("error", "El correo electrónico ya está registrado");
            return "register";
        }

        try {
            // Asignar rol por defecto: COMPRADOR
            usuario.setRol("COMPRADOR"); // Sin ROLE_, el service lo agregará
            usuario.setEstado(1); // Activo

            System.out.println("Intentando guardar usuario...");

            // Guardar usuario (la contraseña se encripta en el service)
            usuarioService.save(usuario);

            System.out.println("✓ Usuario guardado exitosamente");
            System.out.println("=== FIN REGISTRO ===");

            redirectAttributes.addFlashAttribute("mensaje", "Registro exitoso. Ahora puedes iniciar sesión.");
            return "redirect:/login?registro=exitoso";

        } catch (Exception e) {
            System.err.println("✗ ERROR AL GUARDAR USUARIO:");
            System.err.println("Mensaje: " + e.getMessage());
            e.printStackTrace();

            model.addAttribute("error", "Error al registrar usuario. Por favor intenta nuevamente.");
            return "register";
        }
    }

    /**
     * Endpoint para obtener token JWT (API REST)
     */
    @PostMapping("/token")
    @ResponseBody
    public String token(@RequestBody AuthRequest req) {
        return repo.findByUsername(req.getUsername())
                .filter(u -> encoder.matches(req.getPassword(), u.getContrasena()))
                .map(u -> jwtService.generateToken(u.getUsername(), u.getRol()))
                .orElse("Credenciales inválidas");
    }

    /**
     * Página de acceso denegado
     */
    @GetMapping("/acceso-denegado")
    public String accesoDenegado() {
        return "error/acceso-denegado";
    }
}